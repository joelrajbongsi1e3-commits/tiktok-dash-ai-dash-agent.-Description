# TikTok AI Agent MVP — version 0.2

This ZIP contains:
- `android/`: native Android app source (Kotlin + Jetpack Compose)
- `backend/`: FastAPI service that calls the OpenAI Responses API from the server

The app's command flow is wired to an HTTPS backend endpoint, but it will not return real AI answers until you deploy the backend, set a server-side API key, and update `BACKEND_URL`.

This is source code, not an installable APK or Play Store release. It has not been built or tested in Android Studio in this environment. TikTok connection, live trend data, video generation, analytics, and posting are future stages.
