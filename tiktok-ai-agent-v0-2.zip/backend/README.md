# Backend setup

This backend keeps the AI provider key on the server, not inside the Android app.

## 1. Install and run locally
Use Python 3.11+ on a computer or cloud host:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="your-key"
export OPENAI_MODEL="gpt-6-luna"
uvicorn main:app --host 0.0.0.0 --port 8000
```

On Windows PowerShell, activate the venv with `.venv\\Scripts\\Activate.ps1` and set:
`$env:OPENAI_API_KEY="your-key"`.

Create an API key through the official OpenAI platform and check the current model availability/pricing before choosing a model. API usage may incur charges.

## 2. Deploy
Deploy this folder to a trusted Python hosting provider with HTTPS. Add `OPENAI_API_KEY` as a server-side secret/environment variable. Never commit it into source control or put it in the Android app.

## 3. Connect Android
In `android/app/src/main/java/com/example/tiktokaiagent/MainActivity.kt`, replace:
`https://YOUR-BACKEND-HOST.example/api/chat`
with your deployed HTTPS endpoint ending in `/api/chat`.

Then rebuild and test the Android app.

## Production requirements still outstanding
This is an MVP backend, not yet production-ready for a public app. Before public launch, add authentication, per-user rate limits/quotas, abuse prevention, monitoring, privacy policy, account deletion if accounts are added, and cost controls. TikTok OAuth/posting, trend discovery, analytics, and video generation are not included yet.
