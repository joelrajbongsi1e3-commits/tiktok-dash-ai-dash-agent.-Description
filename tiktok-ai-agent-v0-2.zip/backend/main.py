import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="TikTok AI Agent API", version="0.2.0")

# Mobile apps call this HTTPS API. Configure allowed origins if you add a web client.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[],
    allow_credentials=False,
    allow_methods=["POST", "GET"],
    allow_headers=["Content-Type", "Authorization"],
)

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
MODEL = os.environ.get("OPENAI_MODEL", "gpt-6-luna")

SYSTEM_INSTRUCTIONS = """
You are TikTok AI Agent, a helpful creator assistant.
Help users create original short-form videos: concepts, hooks, scripts, shot lists,
captions, hashtags, and content calendars. Prefer faceless video ideas when useful.
Treat public videos as inspiration only; do not instruct users to copy or re-upload
other creators' videos without permission. Do not claim to know live trends unless
a live trend data source is actually connected. Never claim you posted or scheduled
content. Publishing and TikTok account integrations are not connected yet.
Be clear, practical, and concise.
"""

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=5000)

@app.get("/health")
def health():
    return {"status": "ok", "service": "TikTok AI Agent API"}

@app.post("/api/chat")
def chat(body: ChatRequest):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(status_code=503, detail="Server owner has not configured the AI API key.")
    try:
        response = client.responses.create(
            model=MODEL,
            instructions=SYSTEM_INSTRUCTIONS,
            input=body.message,
        )
        return {"reply": response.output_text}
    except Exception:
        # Do not expose credentials, stack traces, or provider internals to app users.
        raise HTTPException(status_code=502, detail="AI service request failed. Please try again later.")
