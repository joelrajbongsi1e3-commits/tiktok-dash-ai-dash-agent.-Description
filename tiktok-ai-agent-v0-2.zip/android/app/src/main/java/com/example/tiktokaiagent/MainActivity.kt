package com.example.tiktokaiagent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val BACKEND_URL = "https://YOUR-BACKEND-HOST.example/api/chat"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TikTokAgentApp() }
    }
}

@Composable
fun TikTokAgentApp() {
    var command by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("Try: Give me 5 original TikTok ideas about Meghalaya waterfalls.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFB69DF8),
        background = Color(0xFF0E0F12),
        surface = Color(0xFF17191E)
    )) {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("TikTok AI Agent", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Your creative assistant for original TikTok content.", color = Color.LightGray)
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17191E)),
                    shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("GIVE YOUR AGENT A COMMAND", color = Color(0xFFB69DF8), fontSize = 12.sp)
                        OutlinedTextField(
                            value = command, onValueChange = { command = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("What should I create for you?") },
                            minLines = 3
                        )
                        Button(
                            enabled = !busy && command.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                busy = true
                                result = "Working on your request…"
                                val prompt = command.trim()
                                scope.launch {
                                    result = withContext(Dispatchers.IO) { callBackend(prompt) }
                                    busy = false
                                }
                            }
                        ) { Text(if (busy) "Working…" else "Run AI Agent") }
                        Text("Examples", color = Color.LightGray, fontSize = 12.sp)
                        Suggestion("Write a 20-second faceless video script about Meghalaya") { command = it }
                        Suggestion("Create a caption and hashtags for a rainy mountain view") { command = it }
                        Suggestion("Plan 7 days of original nature videos") { command = it }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17191E)),
                    shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("AGENT RESPONSE", fontWeight = FontWeight.Bold)
                        SelectionContainer { Text(result, color = Color(0xFFE4E1E8)) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Feature("💡", "Ideas", Modifier.weight(1f))
                    Feature("✍️", "Captions", Modifier.weight(1f))
                    Feature("📅", "Planner", Modifier.weight(1f))
                }
                Spacer(Modifier.weight(1f))
                Text("Publishing is not connected yet. Review content before posting.",
                    color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun Suggestion(label: String, onClick: (String) -> Unit) {
    OutlinedButton(onClick = { onClick(label) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
}

@Composable
private fun Feature(icon: String, title: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF17191E)),
        shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(icon, fontSize = 21.sp)
            Text(title, fontSize = 12.sp)
        }
    }
}

private fun callBackend(prompt: String): String {
    if (BACKEND_URL.contains("YOUR-BACKEND-HOST")) {
        return "The app screen is ready, but the backend URL has not been configured yet. Follow backend/README.md to deploy the server, then replace BACKEND_URL in MainActivity.kt with your HTTPS endpoint."
    }
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject().put("message", prompt).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (code in 200..299) JSONObject(response).optString("reply", "No reply returned.")
        else "Backend error ($code): $response"
    } catch (e: Exception) {
        "Could not reach the AI server. Check the backend URL and internet connection. Details: ${e.localizedMessage ?: "network error"}"
    } finally {
        connection?.disconnect()
    }
}
